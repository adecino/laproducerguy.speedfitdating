<?php

/**
 * Localize strings for javascript
 */

return array(
	'edit-with-cornerstone'      => __( 'Edit with X Pro', 'cornerstone' ),
	'cornerstone-tab'            => __( 'X Pro', 'cornerstone' ),
	'default-title'              => __( 'Content Draft', 'cornerstone')
);
